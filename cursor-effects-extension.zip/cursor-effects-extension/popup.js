const buttons = document.querySelectorAll('.effect-btn');
const offBtn = document.getElementById('offBtn');

// Mevcut efekti yükle
chrome.storage.local.get(['cursorEffect'], (result) => {
  const active = result.cursorEffect || 'none';
  updateUI(active);
});

buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    const effect = btn.dataset.effect;
    setEffect(effect);
  });
});

offBtn.addEventListener('click', () => {
  setEffect('none');
});

function setEffect(effect) {
  chrome.storage.local.set({ cursorEffect: effect });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'SET_EFFECT',
        effect: effect
      });
    }
  });

  updateUI(effect);
}

function updateUI(effect) {
  buttons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.effect === effect);
  });
  offBtn.classList.toggle('active', effect === 'none');
}
