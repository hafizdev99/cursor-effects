// Cursor Effects - Content Script

let currentEffect = 'none';
let hue = 0;
let particles = [];
let animationFrame = null;
let mouseX = 0, mouseY = 0;
let lastX = 0, lastY = 0;

// ── Yükleme ──────────────────────────────────────────────
chrome.storage.local.get(['cursorEffect'], (result) => {
  currentEffect = result.cursorEffect || 'none';
  if (currentEffect !== 'none') startEffect();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'SET_EFFECT') {
    stopEffect();
    currentEffect = msg.effect;
    if (currentEffect !== 'none') startEffect();
  }
});

// ── Başlat / Durdur ──────────────────────────────────────
function startEffect() {
  document.addEventListener('mousemove', onMouseMove);
  loop();
}

function stopEffect() {
  document.removeEventListener('mousemove', onMouseMove);
  cancelAnimationFrame(animationFrame);
  animationFrame = null;
  particles.forEach(p => p.el && p.el.remove());
  particles = [];
}

function onMouseMove(e) {
  lastX = mouseX; lastY = mouseY;
  mouseX = e.clientX; mouseY = e.clientY;
  spawnParticle(e.clientX, e.clientY);
}

// ── Ana döngü ─────────────────────────────────────────────
function loop() {
  hue = (hue + 3) % 360;

  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life -= p.decay;
    p.vy += p.gravity || 0;
    p.vx *= p.friction || 1;
    p.vy *= p.friction || 1;
    p.x += p.vx;
    p.y += p.vy;
    p.rotation = (p.rotation || 0) + (p.rotSpeed || 0);

    const el = p.el;
    if (!el) { particles.splice(i, 1); continue; }

    el.style.left = p.x + 'px';
    el.style.top  = p.y + 'px';
    el.style.opacity = Math.max(0, p.life);
    el.style.transform = buildTransform(p);

    if (p.life <= 0) { el.remove(); particles.splice(i, 1); }
  }

  animationFrame = requestAnimationFrame(loop);
}

function buildTransform(p) {
  let t = `translate(-50%, -50%)`;
  if (p.scale !== undefined) t += ` scale(${p.scale * p.life})`;
  if (p.rotation !== undefined) t += ` rotate(${p.rotation}deg)`;
  return t;
}

// ── Yardımcı: DOM parçacık oluştur ───────────────────────
function makeEl(x, y, css) {
  const el = document.createElement('div');
  el.style.cssText = `
    position: fixed;
    pointer-events: none;
    z-index: 2147483647;
    left: ${x}px;
    top: ${y}px;
    ${css}
  `;
  document.body.appendChild(el);
  return el;
}

function limit(max) {
  if (particles.length > max) {
    const old = particles.shift();
    old.el && old.el.remove();
  }
}

// ══════════════════════════════════════════════════════════
//  EFEKTLER
// ══════════════════════════════════════════════════════════
function spawnParticle(x, y) {
  switch (currentEffect) {

    // 1. RGB Trail
    case 'rgb': {
      const h = hue;
      const el = makeEl(x, y, `
        width:14px; height:14px; border-radius:50%;
        background: hsl(${h},100%,60%);
        box-shadow: 0 0 8px 3px hsl(${h},100%,60%), 0 0 20px 6px hsl(${h},100%,50%);
      `);
      particles.push({ el, x, y, vx:0, vy:0, life:1, decay:0.035, scale:1, friction:1 });
      limit(70);
      break;
    }

    // 2. Alev (Fire)
    case 'fire': {
      for (let i = 0; i < 3; i++) {
        const size = 8 + Math.random() * 12;
        const lightness = 50 + Math.random() * 30;
        const fireHue = Math.random() * 40; // kırmızı-turuncu
        const el = makeEl(x, y, `
          width:${size}px; height:${size}px; border-radius:50% 50% 30% 30%;
          background: radial-gradient(circle, hsl(${fireHue},100%,${lightness}%), hsl(${fireHue+20},100%,30%));
          box-shadow: 0 0 6px 2px hsl(${fireHue},100%,50%);
          filter: blur(1px);
        `);
        particles.push({
          el, x, y,
          vx: (Math.random() - 0.5) * 2,
          vy: -(1 + Math.random() * 3),
          life: 1, decay: 0.04 + Math.random() * 0.02,
          scale: 1, gravity: -0.05, friction: 0.97
        });
      }
      limit(120);
      break;
    }

    // 3. Kar Taneleri
    case 'snow': {
      for (let i = 0; i < 2; i++) {
        const size = 4 + Math.random() * 8;
        const el = makeEl(x, y, `
          width:${size}px; height:${size}px; border-radius:50%;
          background: white;
          box-shadow: 0 0 4px 2px rgba(200,230,255,0.8);
        `);
        particles.push({
          el, x, y,
          vx: (Math.random() - 0.5) * 2,
          vy: -(Math.random() * 1.5),
          life: 1, decay: 0.02,
          scale: 1, gravity: 0.05, friction: 0.99
        });
      }
      limit(100);
      break;
    }

    // 4. Yıldız Patlaması
    case 'stars': {
      for (let i = 0; i < 2; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1 + Math.random() * 3;
        const starH = Math.random() * 360;
        const el = makeEl(x, y, `
          width:6px; height:6px;
          clip-path: polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%);
          background: hsl(${starH},100%,70%);
          box-shadow: 0 0 6px hsl(${starH},100%,70%);
        `);
        particles.push({
          el, x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1, decay: 0.025,
          scale: 1, rotation: 0, rotSpeed: 5 + Math.random() * 10,
          gravity: 0.05, friction: 0.97
        });
      }
      limit(100);
      break;
    }

    // 5. Matrix Kodu
    case 'matrix': {
      const chars = '01アイウエオカキクケコ';
      const char = chars[Math.floor(Math.random() * chars.length)];
      const el = makeEl(x, y, `
        color: #00ff41;
        font-family: monospace;
        font-size: ${10 + Math.random() * 10}px;
        font-weight: bold;
        text-shadow: 0 0 8px #00ff41, 0 0 16px #00ff41;
        white-space: nowrap;
      `);
      el.textContent = char;
      particles.push({
        el, x, y,
        vx: (Math.random() - 0.5),
        vy: 1 + Math.random() * 2,
        life: 1, decay: 0.025, friction: 0.99
      });
      limit(60);
      break;
    }

    // 6. Kalpler
    case 'hearts': {
      const heartH = Math.random() * 60 - 10; // kırmızı-pembe
      const size = 12 + Math.random() * 10;
      const el = makeEl(x, y, `
        width:${size}px; height:${size}px;
        font-size:${size}px;
        line-height:1;
        color: hsl(${(heartH + 360) % 360},100%,65%);
        filter: drop-shadow(0 0 4px hsl(${(heartH+360)%360},100%,65%));
      `);
      el.textContent = '❤';
      particles.push({
        el, x, y,
        vx: (Math.random() - 0.5) * 2,
        vy: -(1.5 + Math.random() * 2),
        life: 1, decay: 0.022,
        gravity: 0.03, friction: 0.98
      });
      limit(60);
      break;
    }

    // 7. Baloncuklar
    case 'bubbles': {
      const size = 10 + Math.random() * 20;
      const bH = Math.random() * 360;
      const el = makeEl(x, y, `
        width:${size}px; height:${size}px; border-radius:50%;
        background: transparent;
        border: 2px solid hsla(${bH},80%,70%,0.8);
        box-shadow: inset 0 0 6px hsla(${bH},80%,90%,0.3), 0 0 6px hsla(${bH},80%,70%,0.4);
      `);
      particles.push({
        el, x, y,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -(0.5 + Math.random() * 1.5),
        life: 1, decay: 0.015,
        scale: 1, gravity: -0.02, friction: 0.99
      });
      limit(60);
      break;
    }

    // 8. Şimşek / Elektrik
    case 'electric': {
      for (let i = 0; i < 2; i++) {
        const size = 3 + Math.random() * 5;
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 4;
        const el = makeEl(x, y, `
          width:${size}px; height:${size * 3}px; border-radius:2px;
          background: linear-gradient(to bottom, #fff, #88f, #44f);
          box-shadow: 0 0 8px 2px #88f, 0 0 16px 4px #44f;
          transform-origin: center center;
        `);
        particles.push({
          el, x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1, decay: 0.07,
          scale: 1, rotation: Math.random() * 360, rotSpeed: 10,
          friction: 0.92
        });
      }
      limit(80);
      break;
    }

    // 9. Gökkuşağı Spiral
    case 'rainbow': {
      const el = makeEl(x, y, `
        width:10px; height:10px; border-radius:50%;
        background: hsl(${hue},100%,65%);
        box-shadow: 0 0 6px 2px hsl(${hue},100%,55%), 0 0 14px 4px hsl(${(hue+30)%360},100%,50%);
      `);
      const angle = (hue / 360) * Math.PI * 2;
      particles.push({
        el, x, y,
        vx: Math.cos(angle) * 1.5,
        vy: Math.sin(angle) * 1.5,
        life: 1, decay: 0.03, scale: 1, friction: 0.98
      });
      limit(80);
      break;
    }

    // 10. Patlama / Confetti
    case 'confetti': {
      for (let i = 0; i < 3; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 5;
        const w = 5 + Math.random() * 6;
        const h = 4 + Math.random() * 5;
        const cH = Math.random() * 360;
        const el = makeEl(x, y, `
          width:${w}px; height:${h}px;
          background: hsl(${cH},100%,60%);
          border-radius:1px;
        `);
        particles.push({
          el, x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 2,
          life: 1, decay: 0.02,
          rotation: Math.random() * 360, rotSpeed: (Math.random() - 0.5) * 15,
          gravity: 0.1, friction: 0.97
        });
      }
      limit(150);
      break;
    }

    // 11. Buz / Kristal
    case 'ice': {
      for (let i = 0; i < 2; i++) {
        const size = 6 + Math.random() * 8;
        const angle = Math.random() * Math.PI * 2;
        const speed = 1 + Math.random() * 2;
        const el = makeEl(x, y, `
          width:${size}px; height:${size}px;
          background: linear-gradient(135deg, rgba(200,240,255,0.9), rgba(100,200,255,0.5));
          border: 1px solid rgba(180,230,255,0.8);
          box-shadow: 0 0 6px rgba(100,200,255,0.6);
          clip-path: polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);
        `);
        particles.push({
          el, x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1, decay: 0.02,
          scale: 1, rotation: Math.random() * 360, rotSpeed: 2,
          friction: 0.97
        });
      }
      limit(80);
      break;
    }

    // 12. Duman / Smoke
    case 'smoke': {
      const size = 20 + Math.random() * 20;
      const gray = Math.floor(150 + Math.random() * 80);
      const el = makeEl(x, y, `
        width:${size}px; height:${size}px; border-radius:50%;
        background: radial-gradient(circle, rgba(${gray},${gray},${gray},0.4), transparent);
        filter: blur(4px);
      `);
      particles.push({
        el, x, y,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -(0.3 + Math.random() * 0.8),
        life: 1, decay: 0.012,
        scale: 1.5, gravity: -0.01, friction: 0.99
      });
      limit(50);
      break;
    }

  }
}
